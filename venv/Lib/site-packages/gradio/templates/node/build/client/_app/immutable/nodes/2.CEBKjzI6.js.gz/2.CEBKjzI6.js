import{Y as e,_ as n}from"../chunks/2.DkBldhLH.js";export{e as component,n as universal};
//# sourceMappingURL=2.CEBKjzI6.js.map
