import{I as r,c as a}from"./mermaid-parser.core.x_dTlpHC.js";export{r as InfoModule,a as createInfoServices};
//# sourceMappingURL=info-63CPKGFF.D4ed3urg.js.map
