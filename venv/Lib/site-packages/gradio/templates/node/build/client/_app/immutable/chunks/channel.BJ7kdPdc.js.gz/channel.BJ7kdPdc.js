import{U as a,C as n}from"./mermaid.core.B0Ot9kP3.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.BJ7kdPdc.js.map
