import{G as a,f as G}from"./mermaid-parser.core.x_dTlpHC.js";export{a as GitGraphModule,G as createGitGraphServices};
//# sourceMappingURL=gitGraph-ZV4HHKMB.DQiSc3Xw.js.map
