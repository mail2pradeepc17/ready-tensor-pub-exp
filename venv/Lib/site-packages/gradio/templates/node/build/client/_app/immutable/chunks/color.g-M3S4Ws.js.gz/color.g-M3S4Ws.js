import{r}from"./2.DkBldhLH.js";const t=o=>r[o%r.length];export{t as g};
//# sourceMappingURL=color.g-M3S4Ws.js.map
