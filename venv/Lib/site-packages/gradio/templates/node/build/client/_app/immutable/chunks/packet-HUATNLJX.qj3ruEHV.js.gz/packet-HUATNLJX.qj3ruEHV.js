import{P as c,a as r}from"./mermaid-parser.core.x_dTlpHC.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-HUATNLJX.qj3ruEHV.js.map
