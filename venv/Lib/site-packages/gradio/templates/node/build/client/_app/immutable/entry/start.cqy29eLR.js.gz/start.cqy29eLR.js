import{s as t}from"../chunks/client.DfhAhigx.js";export{t as start};
//# sourceMappingURL=start.cqy29eLR.js.map
